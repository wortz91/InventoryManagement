<?php
	$con = mysql_connect("localhost","frank73_s15inv","Inventory15");
       if (!$con){
       die('Could not connect: ' . mysql_error());
       }
       mysql_select_db("frank73_s15inv", $con);
	
	$ItemID=$_REQUEST['ItemID'];
	$Label=$_REQUEST['Label'];
	$ItemName=$_REQUEST['ItemName'];
	$Category=$_REQUEST['Category'];
	$ModelNumber=$_REQUEST['ModelNumber'];
	$ConditionID=$_REQUEST['ConditionID'];
	$Location=$_REQUEST['Location'];
	$Latitude=$_REQUEST['Latitude'];
	$Longitude=$_REQUEST['Longitude'];
	$LastEditDate=$_REQUEST['LastEditDate'];
	$LastEditUser=$_REQUEST['LastEditUser'];

	

	$sql ="UPDATE frank73_s15inv.ItemInformation SET Label ='$Label', ItemName = '$ItemName', Category = '$Category', ModelNumber = '$ModelNumber', ConditionID = '$ConditionID', Location = '$Location', Latitude = '$Latitude', Longitude = '$Longitude', LastEditDate = '$LastEditDate', LastEditUser = '$LastEditUser' WHERE ItemID = '$ItemID'";
	
	if(mysql_query($sql,$con)){
		$flag['code']=1;
	} else {
		$flag['code']=0;
		mysql_error($con);
	}

	print(json_encode($flag));
	mysql_close($con);
?>