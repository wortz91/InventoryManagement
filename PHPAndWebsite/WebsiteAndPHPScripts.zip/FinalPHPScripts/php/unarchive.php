<?php	

	$con = mysql_connect("localhost","frank73_s15inv","Inventory15");
	
	if (!$con){
	   die('Could not connect: ' . mysql_error());
	}
	mysql_select_db("frank73_s15inv", $con);
   
	$itemID=$_REQUEST['ItemID'];
	$deleteID=$_REQUEST['DeleteID'];

	// searchMatch is used to determine if there is an item that was selected to unarchive and delete.
	$searchMatch = false;

	// checks to see if any items were selected.
	if(empty($itemID) && empty($deleteID)) {
		$message = "No items selected.";
		echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/archive.php';
				</script>";

	// If items are selected, check if there are multiple items (is this an array?).
	// If not multiple items, convert to array in order to compare if both boxes were checked.
	} else {
		if (!is_array($itemID)) {
			$itemID = array($itemID);
		}
		if (!is_array($deleteID)) {
			$deleteID = array($deleteID);
		}
	// compares the arrays to see if there are any identical items.  If found, searchMatch = true.
		foreach($itemID as $item) {
			foreach($deleteID as $delete) {
				if ($item == $delete) {
					$searchMatch = true;
				}
			}
		}

		// If a match was found, throw an error.
		if ($searchMatch) {
			$message = "Error: Cannot unarchive and delete the same item.";
			echo "<script type='text/javascript'>alert('$message');
			window.location='http://s15inventory.franklinpracticum.com/archive.php';
			</script>";

		// If no error was found, run the script as normal	
		} else {

			// The following two if statements are used to convert the arrays to
			// null objects if they did not have a value.  Otherwise, the counts
			// would come up incorrect, and damage the rest of the script.
			if ($itemID[0] == null) {
				$itemID = null;
			}
			if ($deleteID[0] == null) {
				$deleteID = null;
			}
			
			$N = count($itemID);
			$M = count($deleteID);
			
			if (isset($itemID[0])) {
				for($i=0; $i < $N; $i++) {
				$sql = "INSERT INTO frank73_s15inv.ItemInformation (ItemID, Label, ItemName, Category, ModelNumber, ConditionID, Location, Latitude,
				Longitude, CreateDate, LastEditDate, LastEditUser) SELECT ItemID, Label, ItemName, Category, ModelNumber, ConditionID, Location,
				Latitude, Longitude, CreateDate, LastEditDate, LastEditUser FROM frank73_s15inv.ArchivedData WHERE ItemID ='$itemID[$i]'";
				
					if(mysql_query($sql,$con)){
						$sql = "DELETE FROM frank73_s15inv.ArchivedData WHERE ItemID ='$itemID[$i]'";
						if(!mysql_query($sql,$con)){
							mysql_error($con);
						}
					} else {
						$message = "Error: Item with same serial number or label already exists in inventory.";
						$isError = true;
						mysql_error($con);
					}
				}
			}
			if (isset($deleteID)) {
				for($i=0; $i < $M; $i++) {
					$sql = "DELETE FROM frank73_s15inv.ArchivedData WHERE ItemID ='$deleteID[$i]'";
					if(!mysql_query($sql,$con)){
						mysql_error($con);
					}
				}
			}
			$message = "$N item(s) returned to inventory and $M item(s) deleted.";
			echo "<script type='text/javascript'>alert('$message');
			window.location='http://s15inventory.franklinpracticum.com/archive.php';
			</script>";
		}
	}
	mysql_close($con);
?>
