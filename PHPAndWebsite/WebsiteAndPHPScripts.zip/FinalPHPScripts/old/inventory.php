<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Inventory Management</title>
		<style>
			@import 'reset.css';
			@import url(http://fonts.googleapis.com/css?family=Roboto);
			@import 'style.css';
			@import 'main.css';
		</style>
	</head>
	<body>
		<div id="header"> 

		<img class="logo" src="images/inv_man_trans.png"><br/>
		<ul>
			<li id="selected"><a href="inventory.php">Current Inventory</a></li>
			<li><a href="archive.php">Archive</a></li>
			<li><a href="users.html">Users</a></li>
		</ul>

		</div>
		<div id="content">
			<div id="table">
				<?php
				$servername='localhost';
				$username='frank73_s15inv';
				$password='Inventory15';
				$dbname="frank73_s15inv";

				$conn = new mysqli($servername, $username, $password, $dbname);

				$sql = "SELECT * FROM frank73_s15inv.ItemInformation";
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {
					echo "<table>
						<tr>
							<th>Archive</th>
							<th>Item ID</th>
							<th>Label</th>
							<th>Item Name</th>
							<th>Category</th>
							<th>Model Number</th>
							<th>Condition</th>
							<th>Location</th>
							<th>Latitude</th>
							<th>Longitude</th>
							<th>Creation Date</th>
							<th>Edit Date</th>
							<th>Edit User</th>
						</tr>";
						while ($row = $result->fetch_assoc()) {
						echo "<tr>
								<td>
									<input type='checkbox' name='archive'>
								</td>
								<td>" . $row["ItemID"] . "</td>
								<td>" . $row["Label"] . "</td>
								<td>" . $row["ItemName"] . "</td>
								<td>" . $row["Category"] . "</td>
								<td>" . $row["ModelNumber"] . "</td>
								<td>" . $row["ConditionID"] . "</td>
								<td>" . $row["Location"] . "</td>
								<td>" . $row["Latitude"] . "</td>
								<td>" . $row["Longitude"] . "</td>
								<td>" . $row["CreateDate"] . "</td>
								<td>" . $row["LastEditDate"] . "</td>
								<td>" . $row["LastEditUser"] . "</td>
							</tr>";
						}
						echo "</table>";
						} else {
						echo "No results";
						}
						$conn->close();
				?>	
			</div>
			<div id="button">
				<input class="login" type="button" value="Archive" onclick="window.location.href='archive.php';">
			</div>
		</div>
	</body>
</html>
