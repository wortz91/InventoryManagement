<?php
	session_start();
	if ($_SESSION['status'] !='authorized') header('location: index.html');
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Inventory Management</title>
		<style>
			@import 'reset.css';
			@import url(http://fonts.googleapis.com/css?family=Roboto);
			@import 'style.css';
			@import 'main.css';
		</style>
	</head>
	<body>
		<div id="header"> 
			<form id='logout' action='php/adminLogout.php' method='post'>
				<input type="submit" value="Logout" onClick="php/adminLogout.php">
			</form>

		<img class="logo" src="images/inv_man_trans.png"><br/>
		
		<ul>
			<li id="selected"><a href="inventory.php">Current Inventory</a></li>
			<li><a href="archive.php">Archive</a></li>
			<li><a href="users.php">Users</a></li>
		</ul>
		</div>
		<div id="content">
			<div id="table">
				<?php
				$servername='localhost';
				$username='frank73_s15inv';
				$password='Inventory15';
				$dbname="frank73_s15inv";

				$conn = new mysqli($servername, $username, $password, $dbname);

				$sql = "SELECT * FROM frank73_s15inv.ItemInformation";
				$result = $conn->query($sql);
				

				if ($result->num_rows > 0) {
					echo "<table>
						<tr>
							<th>Archive</th>
							<th>Label</th>
							<th>Serial Number</th>
							<th>Item Name</th>
							<th>Category</th>
							<th>Model Number</th>
							<th>Condition</th>
							<th>Location</th>
							<th>Latitude</th>
							<th>Longitude</th>
							<th>Creation Date</th>
							<th>Edit Date</th>
							<th>Edit User</th>
						</tr>
						<form action='/php/archive.php' method='post'>";
						while ($row = $result->fetch_assoc()) {
							echo "<tr>
									<td>
										<input type='checkbox' name='ItemID[]' value=" . $row["ItemID"] . ">
									</td>
									<td>" . $row["ItemID"] . "</td>
									<td>" . $row["Label"] . "</td>
									<td>" . $row["ItemName"] . "</td>
									<td>" . $row["Category"] . "</td>
									<td>" . $row["ModelNumber"] . "</td>
									<td>" . $row["ConditionID"] . "</td>
									<td>" . $row["Location"] . "</td>
									<td>" . $row["Latitude"] . "</td>
									<td>" . $row["Longitude"] . "</td>
									<td>" . $row["CreateDate"] . "</td>
									<td>" . $row["LastEditDate"] . "</td>
									<td>" . $row["LastEditUser"] . "</td>
								</tr>";
						}
						echo "</table>";
				} else {
				echo "No results";
				}
				$conn->close();
				?>	
			</div>
			<div id="button">
				<table class="noLines">
					<td class="noLines"><input class="login" type="submit" value="Submit"></td>
				</form>
				</table>
			</div>
		</div>
	</body>
</html>
