<?php
	$host='localhost';
	$uname='frank73_s15inv';
	$pwd='Inventory15';
	$db="frank73_s15inv";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$itemid=$_REQUEST['itemid'];

	$flag['code']=0;

	if($r=mysql_query("DELETE FROM frank73_s15inv.ArchiveData WHERE itemid ='$itemid') ",$con))
	{
		$flag['code']=1;
		echo"hi";
	}

	print(json_encode($flag));
	mysql_close($con);
?>