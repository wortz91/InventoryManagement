

<?php

    

    if(isset($_REQUEST['Label']))

       {

       $con = mysql_connect("localhost","frank73_s15inv","Inventory15");

       if (!$con)

       {

       die('Could not connect: ' . mysql_error());

       }

       mysql_select_db("frank73_s15inv", $con);

       

       	$Label=$_REQUEST['Label'];
		$ItemName=$_REQUEST['ItemName'];
		$Category=$_REQUEST['Category'];
		$ModelNumber=$_REQUEST['ModelNumber'];
		$ConditionID=$_REQUEST['ConditionID'];
		$Location=$_REQUEST['Location'];
		$Latitude=$_REQUEST['Latitude'];
		$Longitude=$_REQUEST['Longitude'];
		$CreateDate=$_REQUEST['CreateDate'];
		$LastEditDate=$_REQUEST['LastEditDate'];
		$LastEditUser=$_REQUEST['LastEditUser'];

       

       $result = mysql_query("SELECT * FROM frank73_s15inv.ItemInformation WHERE Label LIKE '%$Label%' OR ItemName LIKE '%$ItemName%' OR 
       	Category LIKE '%$Category' OR ModelNumber LIKE '%$ModelNumber%' OR ConditionID LIKE '%$ConditionID%' OR Location LIKE '%$Location%' OR
       	Latitude LIKE '%$Latitude%' OR Longitude LIKE '%$Longitude%' OR CreateDate LIKE '%$CreateDate%' OR LastEditDate LIKE '%$LastEditDate%' OR LastEditUser LIKE '%$LastEditUser%'; ") or die('Errant query:');

       

       

       while($row = mysql_fetch_assoc($result))

       {

            $output[]=$row;

       }

       

       print(json_encode($output));

       

       mysql_close($con);

       }

    else

       {

       $output = "not found";

       print(json_encode($output));

       }

?>