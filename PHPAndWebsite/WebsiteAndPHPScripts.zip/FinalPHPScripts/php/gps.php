<?php
	$host='localhost';
	$uname='frank73_s15inv';
	$pwd='Inventory15';
	$db="frank73_s15inv";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$itemid=$_REQUEST['itemid'];
	$label=$_REQUEST['label'];
	$itemname=$_request['itemname'];
	$category=$_request['category'];
	$modelnumber=$_request['modelnumber'];
	$conditionid=$_request['conditionid'];
	$location=$_request['location'];
	$longitude=$_request['longitude'];
	$latitude=$_request['latitude'];
	$createdate=$_request['createdate'];
	$lasteditdate=$_request['lasteditdate'];
	$lastedituser=$_request['lastedituser'];

	$flag['code']=0;

	if($r=mysql_query("UPDATE frank73_s15inv.TestTable SET longitude = '$longitude', latitude = '$latitude' WHERE id = $id ",$con))
	{
		$flag['code']=1;
		echo"hi";
	}

	print(json_encode($flag));
	mysql_close($con);
?>