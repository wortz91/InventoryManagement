<?php
	$host='localhost';
	$uname='frank73_s15inv';
	$pwd='Inventory15';
	$db="frank73_s15inv";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$user=$_REQUEST['username'];
	$pass=$_REQUEST['password'];

	$flag['code']=0;

	$r = mysql_query("SELECT username,password, admin FROM frank73_s15inv.Users WHERE username='$user'",$con);

    $row = mysql_fetch_array($r);
  	$uname = $row[0];
   	$pwrd = $row[1];
	$admin = $row[2];
    
	if ($uname == $user) {
		if ($admin == 0) {
			die ();
		}
		if ($pwrd == $pass) {
			$flag['code'] = 1;
		} else {
			die();
		}
	} else {
        	die();
    	}
	print(json_encode($flag));
	mysql_close($con);
?>