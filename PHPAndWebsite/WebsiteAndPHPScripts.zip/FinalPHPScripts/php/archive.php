<?php	

	$con = mysql_connect("localhost","frank73_s15inv","Inventory15");

	if (!$con){
	   die('Could not connect: ' . mysql_error());
	}
	mysql_select_db("frank73_s15inv", $con);
	   
	$ItemID=$_REQUEST['ItemID'];

	if(empty($ItemID)) {
		$message = "No items selected.";
		echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/inventory.php';
				</script>";
	} else {
		$N = count($ItemID);
		
		for($i=0; $i < $N; $i++) {
			$sql = "INSERT INTO frank73_s15inv.ArchivedData (ItemID, Label, ItemName, Category, ModelNumber, ConditionID, Location, Latitude,
			Longitude, CreateDate, LastEditDate, LastEditUser) SELECT ItemID, Label, ItemName, Category, ModelNumber, ConditionID, Location,
			Latitude, Longitude, CreateDate, LastEditDate, LastEditUser FROM frank73_s15inv.ItemInformation WHERE ItemID ='$ItemID[$i]'";
			
			if(mysql_query($sql,$con)){
				$sql = "DELETE FROM frank73_s15inv.ItemInformation WHERE ItemID ='$ItemID[$i]'";
				if(!mysql_query($sql,$con)){
					mysql_error($con);
				}
			} else {
				mysql_error($con);
			}
		}
		$message = "$N item(s) moved to archive.";
		echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/inventory.php';
				</script>";
	}
	mysql_close($con);
?>