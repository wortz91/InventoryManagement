<?php
	$con = mysql_connect("localhost","frank73_s15inv","Inventory15");
       if (!$con){
       die('Could not connect: ' . mysql_error());
       }
       mysql_select_db("frank73_s15inv", $con);
	
	$ItemID=$_REQUEST['ItemID'];

	$sql = "INSERT INTO frank73_s15inv.ArchivedData (ItemID, Label, ItemName, Category, ModelNumber, ConditionID, Location, Latitude, Longitude, CreateDate, LastEditDate, LastEditUser) SELECT ItemID, Label, ItemName, Category, ModelNumber, ConditionID, Location, Latitude, Longitude, CreateDate, LastEditDate, LastEditUser FROM frank73_s15inv.ItemInformation WHERE ItemID ='$ItemID'";
	if(mysql_query($sql,$con)){
		$sql = "DELETE FROM frank73_s15inv.ItemInformation WHERE ItemID ='$ItemID'";
		if(mysql_query($sql,$con)){
			$flag['code']=1;
		} else {
			$flag['code']=0;
			mysql_error($con);
		}
	} else {
		$flag['code']=0;
		mysql_error($con);
	}
	

	
	print(json_encode($flag));
	mysql_close($con);
?>