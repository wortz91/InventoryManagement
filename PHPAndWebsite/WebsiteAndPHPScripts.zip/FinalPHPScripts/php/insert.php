<?php
	$host='localhost';
	$uname='frank73_s15inv';
	$pwd='Inventory15';
	$db="frank73_s15inv";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$Label=$_REQUEST['Label'];
	$ItemName=$_REQUEST['ItemName'];
	$Category=$_REQUEST['Category'];
	$ModelNumber=$_REQUEST['ModelNumber'];
	$ConditionID=$_REQUEST['ConditionID'];
	$Location=$_REQUEST['Location'];
	$Latitude=$_REQUEST['Latitude'];
	$Longitude=$_REQUEST['Longitude'];
	$CreateDate=$_REQUEST['CreateDate'];
	$LastEditDate=$_REQUEST['LastEditDate'];
	$LastEditUser=$_REQUEST['LastEditUser'];

	$flag['code']=0;

	if($r=mysql_query("INSERT INTO `frank73_s15inv`.`ItemInformation` (`Label`, `ItemName`, `Category`, `ModelNumber`, `ConditionID`, `Location`, `Latitude`, `Longitude`, `CreateDate`, `LastEditDate`, `LastEditUser`) " . 
						"VALUES ('$Label', '$ItemName', '$Category', '$ModelNumber', '$ConditionID', '$Location', '$Latitude', '$Longitude', '$CreateDate', '$LastEditDate', '$LastEditUser')",$con))
	// if($r=mysql_query("INSERT INTO `frank73_s15inv`.`ItemInformation` (`Label`, `ItemName`, `Category`, `ModelNumber`, `ConditionID`, `Location`, `Latitude`, `Longitude`, `CreateDate`, `LastEditDate`, `LastEditUser`) VALUES ('s', 'g', 'j', '2', '4', 'hh', '0.0', '9.9', 'null', 'null', 'test')",$con))
	{
		$flag['code']=1;
	}

	print(json_encode($flag));
	mysql_close($con);
?>