<?php
	$host='localhost';
	$uname='frank73_s15inv';
	$pwd='Inventory15';
	$db="frank73_s15inv";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$user=$_REQUEST['DeleteUser'];
	
	if(empty($user)) {
		$message = "No users selected.";
		echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/users.php';
				</script>";
	} else {
		$N = count($user);
		
		for($i=0; $i < $N; $i++) {
			$sql = "DELETE FROM frank73_s15inv.Users WHERE Username = '$user[$i]'";
			
			mysql_query($sql,$con);
			$message = "$N user(s) deleted successfully.";
			echo "<script type='text/javascript'>alert('$message');
					window.location='http://s15inventory.franklinpracticum.com/users.php';
					</script>";
		}
	}
	mysql_close($con);
?>