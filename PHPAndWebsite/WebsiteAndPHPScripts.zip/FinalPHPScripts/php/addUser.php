<?php
	$host='localhost';
	$uname='frank73_s15inv';
	$pwd='Inventory15';
	$db="frank73_s15inv";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$user=$_REQUEST['user'];
	$password=$_REQUEST['password'];
	$admin=$_REQUEST['admin'];

	if (empty($user) || empty($password)) {
		$message = "Username and/or password cannot be left blank.";
		echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/addUser.php';
			</script>";
	} else if (preg_match('/\s/',$user) || preg_match('/\s/',$password)) {
		$message = "Username and password cannot contain spaces.";
		echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/addUser.php';
			</script>";
	} else {		

		if (mysql_query("INSERT INTO frank73_s15inv.Users VALUES ('$user', '$password', $admin)", $con)) {
			$message = "User $user added successfully.";
			echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/users.php';
			</script>";
		} else {
			$message = "An error occurred. User $user has not been added.";
			echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/users.php';
			</script>";
		}
	}
	mysql_close($con);
?>