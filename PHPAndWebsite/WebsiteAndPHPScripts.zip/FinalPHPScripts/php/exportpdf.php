<?php
require('fpdf.php');

date_default_timezone_set('America/Chicago');//or change to whatever timezone you want
$d=date('d_m_Y');

class PDF extends FPDF
{

function Header()
{
    // Select Arial bold 15
    $this->SetFont('Arial','B',15);
	$this->SetTextColor(56,166,100);
    // Move to the right
    $this->Cell(80);
    // Framed title
    $this->Cell(30,10,'Inventory Report',0,0,'C');
    // Line break
    $this->Ln(10);
}

//Page footer
function Footer()
{
   
}

//Simple table
function BasicTable($header,$data)
{ 

$this->SetFillColor(56,166,100);
$this->SetDrawColor(44,44,44);
$w=array(20,20,20,20,20,20,20,20,20,20,20,20,20);
    // Move to the right
    $this->Cell(35);
	//Header
	$this->SetTextColor(255,255,255);
	for($i=0;$i<count($header);$i++)
		$this->Cell($w[$i],7,$header[$i],1,0,'C',true);
			
	$this->Ln();

	//Data
	$this->SetTextColor(2,2,2);
	$this->SetFillColor(239,239,239);
	$fill = false;
	foreach ($data as $eachResult) 
	{ 	// Move to the right
    	$this->Cell(35);
		//width
		$this->Cell(20,6,$eachResult["Label"],1,0,C,$fill);
		$this->Cell(20,6,$eachResult["ItemName"],1,0,C,$fill);
		$this->Cell(20,6,$eachResult["Category"],1,0,C,$fill);
		$this->Cell(20,6,$eachResult["ModelNumber"],1,0,C,$fill);
		$this->Cell(20,6,$eachResult["ConditionID"],1,0,C,$fill);
		$this->Cell(20,6,$eachResult["Location"],1,0,C,$fill);
		$this->Ln();
		$fill = !$fill;	 	 	
	}
}

//Better table
}

$pdf=new PDF();

$header=array('UPC','ITEM NAME','CATEGORY','MODEL NUMBER','CONDITION ID', 'LOCATION');
//Data loading
//*** Load MySQL Data ***//
$objConnect = mysql_connect("localhost","frank73_s15inv","Inventory15") or die("Error:Please check your database username & password");
$objDB = mysql_select_db("frank73_s15inv");
$strSQL = "SELECT Label, ItemName, Category, ModelNumber, ConditionID, Location FROM frank73_s15inv.ItemInformation";
$objQuery = mysql_query($strSQL);
$resultData = array();
for ($i=0;$i<mysql_num_rows($objQuery);$i++) {
	$result = mysql_fetch_array($objQuery);
	array_push($resultData,$result);
}
//************************//
$pdf->SetFont('Arial','',6);

//*** Table 1 ***//
$pdf->AddPage();
$pdf->BasicTable($header,$resultData);
$pdf->Output("InventoryReport$d.pdf","I");

?>