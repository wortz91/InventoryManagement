<?php
	session_start();
	if ($_SESSION['status'] !='authorized') header('location: index.html');
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Inventory Management</title>
		<style>
			@import 'reset.css';
			@import url(http://fonts.googleapis.com/css?family=Roboto);
			@import 'style.css';
			@import 'main.css';
		</style>
	</head>
	<body>
		<div id="header"> 
			<form id='logout' action='php/adminLogout.php' method='post'>
				<input type="submit" value="Logout" onClick="php/adminLogout.php">
			</form>
		<img class="logo" src="images/inv_man_trans.png"><br/>
		<ul>
			<li><a href="inventory.php">Current Inventory</a></li>
			<li><a href="archive.php">Archive</a></li>
			<li id="selected"><a href="users.php">Users</a></li>
		</ul>

		</div>
		<div id="content">
			<div id="table" class="noPad">
			<table>
				<!--<th>Edit</th>-->
				<th>Delete</th>
				<th>User</th>
				<tr>
					<!--<td>
						<input type='checkbox' name='editUser'>
					</td>-->
					<td>
						<input type='checkbox' name='deleteUser'>
					</td>
					<td>test</td>
				</tr>
				<tr>
					<!--<td>
						<input type='checkbox' name='editUser'>
					</td>-->
					<td>
						<input type='checkbox' name='deleteUser'>
					</td>
					<td>test</td>
				</tr>
				<tr>
					<!--<td>
						<input type='checkbox' name='editUser'>
					</td>-->
					<td>
						<input type='checkbox' name='deleteUser'>
					</td>
					<td>test</td>
				</tr>
			</table>
			</div>
			<div id="button">
				<table class="noLines">
			<!--<td class="noLines"><input class="login" type="button" value="Edit User"></td>-->
			<td class="noLines"><input class="login" type="button" value="Delete User"></td>
			<td class="noLines"><input class="login" type="button" value="Add User" onclick="window.location.href='addUser.php';"></td>
		</table>
		</div>
		</div>
	</body>
</html>


