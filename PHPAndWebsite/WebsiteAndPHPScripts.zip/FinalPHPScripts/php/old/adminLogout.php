<?php
	session_start();

	if (isset($_SESSION['status'])) {
		unset($_SESSION['status']);

		if(isset($_COOKIE[session_name()])) {
			setcookie(session_name(), '', time() - 10000);
		}
	}
	header('location: http://s15inventory.franklinpracticum.com/index2.html')
?>