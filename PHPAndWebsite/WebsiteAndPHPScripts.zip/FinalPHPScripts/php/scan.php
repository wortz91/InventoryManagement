<?php
	$host='localhost';
	$uname='frank73_s15inv';
	$pwd='Inventory15';
	$db="frank73_s15inv";

	$con = mysql_connect($host,$uname,$pwd) or die("connection failed");
	mysql_select_db($db,$con) or die("db selection failed");
	 
	$itemid=$_REQUEST['itemid'];
	$label=$_REQUEST['label'];
	$itemname=$_request['itemname'];
	$category=$_request['category'];
	$modelnumber=$_request['modelnumber'];
	$conditionid=$_request['conditionid'];
	$location=$_request['location'];
	$gps=$_request['gps'];
	$createdate=$_request['createdate'];
	$lasteditdate=$_request['lasteditdate'];
	$lastedituser=$_request['lastedituser'];

	$flag['code']=0;

	$r=mysql_query("SELECT * FROM frank73_s15inv.ItemInformation WHERE label ='$label') ",$con);

	while ($row=mysql_fetch_array($r))
	{
		$flag[label]=$row[label];
		$flag[itemname]=$row[itemname];
		$flag[category]=$row[category];
		$flag[modelnumber]=$row[modelnumber];
		$flag[conditionid]=$row[conditionid];
		$flag[location]=$row[location];
		$flag[gps]=$row[gps];
		$flag[createdate]=$row[createdate];
		$flag[lasteditdate]=$row[lasteditdate];
		$flag[lastedituser]=$row[lastedituser];	
	}

	print(json_encode($flag));
	mysql_close($con);
?>