<?php
	session_start();
	if ($_SESSION['status'] !='authorized') header('location: index.html');
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Inventory Management</title>
		<style>
			@import 'reset.css';
			@import url(http://fonts.googleapis.com/css?family=Roboto);
			@import 'style.css';
			@import 'main.css';
		</style>
	</head>
	<body>
		<div id="header"> 
			<form id='logout' action='php/adminLogout.php' method='post'>
				<input type="submit" value="Logout" onClick="php/adminLogout.php">
			</form>
			<img class="logo" src="images/inv_man_trans.png"><br/>
			<ul>
				<li><a href="inventory.php">Current Inventory</a></li>
				<li><a href="archive.php">Archive</a></li>
				<li id="selected"><a href="users.php">Users</a></li>
			</ul>
		</div>
		<div id="content">
			<form action='/php/addUser.php' method='post'>
				<div id="table">
					<table class='noLines'>
						<tr>
							<td class='noLines'>
								<div id='leftJustify'>
									<p>Username</p>
								</div>
							</td>
							<td class='noLines'>
								<input class='login' type='text' name='user' placeholder='Username' maxlength="35">
							</td>
						</tr>
						<tr>
							<td class='noLines'>
								<div id='leftJustify'>
									<p>Password</p>
								</div>
							</td>
							<td class='noLines'>
								<input class='login' type='text' name='password' placeholder='Password' maxlength="35">
							</td>
						</tr>
						<tr>
							<td class='noLines'>
								<div id='leftJustify'>
									<p>Admin</p>
								</div>
							</td>
							<td class='noLines'>
								<div id='radio'>
									<input type='radio' name='admin' value='1'>&nbsp;Yes&nbsp;&nbsp;
									<input type='radio' name='admin' value='0' checked>&nbsp;No
								</div>
							</td>
						</tr>
					</table>
				</div>
				<br>
				<div id="button">
					<table class="noLines">
						<td class="noLines"><input class="login" type="submit" value="Add"></td>
						<td class="noLines"><input class="login" type="button" value="Cancel" onclick="window.location.href='users.php';"></td>
					</table>
				</div>
			</form>
		</div>
	</body>
</html>


