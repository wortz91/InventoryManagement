<?php
	session_start();
	if ($_SESSION['status'] !='authorized') header('location: index.html');
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Inventory Management</title>
		<style>
			@import 'reset.css';
			@import url(http://fonts.googleapis.com/css?family=Roboto);
			@import 'style.css';
			@import 'main.css';
		</style>
	</head>
	<body>
		<div id="header"> 
			<form id='logout' action='php/adminLogout.php' method='post'>
				<input type="submit" value="Logout" onClick="php/adminLogout.php">
			</form>
		<img class="logo" src="images/inv_man_trans.png"><br/>
		<ul>
			<li><a href="inventory.php">Current Inventory</a></li>
			<li><a href="archive.php">Archive</a></li>
			<li id="selected"><a href="users.php">Users</a></li>
		</ul>

		</div>
		<div id="content">
			<div id="table" class="noPad">
			<?php
				$servername='localhost';
				$username='frank73_s15inv';
				$password='Inventory15';
				$dbname="frank73_s15inv";

				$conn = new mysqli($servername, $username, $password, $dbname);

				$sql = "SELECT * FROM frank73_s15inv.Users";
				$result = $conn->query($sql);

				if ($result->num_rows > 0) {
					echo "<table>
						<tr>
							<th>Delete</th>
							<th>User</th>
							<th>Admin</th>
						</tr>";
						while ($row = $result->fetch_assoc()) {
						echo "<tr>
								<td>
									<input type='checkbox' name='delete'>
								</td>
								<td>" . $row["Username"] . "</td>
								<td>";
									if($row['Admin'] =='1') {
										echo "Yes";
									}
									else {
										echo "No";
									}
								echo "</td>
							</tr>";
						}
						echo "</table>";
				} else {
				echo "No results";
				}
				$conn->close();
			?>
			</div>
			<div id="button">
				<table class="noLines">
			<!--<td class="noLines"><input class="login" type="button" value="Edit User"></td>-->
			<td class="noLines"><input class="login" type="button" value="Delete User"></td>
			<td class="noLines"><input class="login" type="button" value="Add User" onclick="window.location.href='addUser.php';"></td>
		</table>
		</div>
		</div>
	</body>
</html>


