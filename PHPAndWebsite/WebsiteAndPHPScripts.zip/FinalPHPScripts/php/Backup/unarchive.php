<?php	

	$con = mysql_connect("localhost","frank73_s15inv","Inventory15");
	
	if (!$con){
	   die('Could not connect: ' . mysql_error());
	}
	mysql_select_db("frank73_s15inv", $con);
   
	$ItemID=$_REQUEST['ItemID'];
	$DeleteID=$_REQUEST['DeleteID'];

	if(empty($ItemID) && empty($DeleteID)) {
		$message = "No items were selected";
		echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/archive.php';
				</script>";
	} else {
		$N = count($ItemID);
		$M = count($DeleteID);
		
		if (isset($ItemID)) {
			for($i=0; $i < $N; $i++) {
			$sql = "INSERT INTO frank73_s15inv.ItemInformation (ItemID, Label, ItemName, Category, ModelNumber, ConditionID, Location, Latitude,
			Longitude, CreateDate, LastEditDate, LastEditUser) SELECT ItemID, Label, ItemName, Category, ModelNumber, ConditionID, Location,
			Latitude, Longitude, CreateDate, LastEditDate, LastEditUser FROM frank73_s15inv.ArchivedData WHERE ItemID ='$ItemID[$i]'";
			
				if(mysql_query($sql,$con)){
					$sql = "DELETE FROM frank73_s15inv.ArchivedData WHERE ItemID ='$ItemID[$i]'";
					if(!mysql_query($sql,$con)){
						mysql_error($con);
					}
				} else {
					mysql_error($con);
				}
			}
		}
		if (isset($DeleteID)) {
			?>
			<script>
				var response = confirm("Are you sure you wish to delete items? Note: Hitting cancel will still delete your items right now.... sorry you're screwed.")
				if (response == false) {
					window.location='http://s15inventory.franklinpracticum.com/archive.php';
				}
			</script>		
			<?php
			for($i=0; $i < $M; $i++) {
				$sql = "DELETE FROM frank73_s15inv.ArchivedData WHERE ItemID ='$DeleteID[$i]'";
				if(!mysql_query($sql,$con)){
					mysql_error($con);
				}
			}
		}
		$message = "$N item(s) were moved back into inventory and $M item(s) were removed successfully";
		echo "<script type='text/javascript'>alert('$message');
				window.location='http://s15inventory.franklinpracticum.com/archive.php';
				</script>";
		}
	mysql_close($con);
?>
