<?php
	$con = $con = mysql_connect("localhost","frank73_s15inv","Inventory15");
	
	if (!$con){
  		die('Could not connect: ' . mysql_error());
  	}
	mysql_select_db("frank73_s15inv",$con);


	$result = mysql_query("SELECT * FROM frank73_s15inv.ItemInformation");

		while($row = mysql_fetch_assoc($result))
		  {
			$output[]=$row;
		  }

	print(json_encode($output));
	
	mysql_close($con);

?>